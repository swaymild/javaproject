package project1;

public interface Example1_1 {

	int pcno = (int)Math.ceil((Math.random()*10));
	public int pcnum();
	public void updown();
	
	
}
